//(c) John Doe 2022
/* $a18 */
#include "semantics.h"
using namespace std;
void tSM::init(){
	globals.clear();
	locals.clear();
	scope = 0; // вне процедуры

  //константы:
	globals["e"] =
		tgName(VAR | DEFINED | BUILT);
	globals["pi"] =
		tgName(VAR | DEFINED | BUILT);
	// ...
	// элементарные процедуры:
	globals["abs"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["tan"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["atan"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["cos"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["exp"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["sin"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["expt"] =
		tgName(PROC | DEFINED | BUILT, "", 2);
	globals["log"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	globals["quotient"] =
		tgName(PROC | DEFINED | BUILT, "", 2);
	globals["remainder"] =
		tgName(PROC | DEFINED | BUILT, "", 2);
	globals["sqrt"] =
		tgName(PROC | DEFINED | BUILT, "", 1);
	return;}
int tSM::p01(){ //       S -> PROG
	bool error = false;
	for (tGlobal::iterator it = globals.begin(); it != globals.end(); ++it) {
		string name = it->first;
		tgName& ref = it->second;
		if (ref.test(VAR)) {
			if (!ref.test(DEFINED) && ref.test(USED)) {
				ferror_message +=
					"Error[01-1] in line " + ref.line + ": there was no declaration of the variable '"
					+ name +
					"'!\n";
				//не было объявления переменной 'a'!
				//there was no declaration of the variable 'a'!
				error = true;
			}
			if (ref.test(DEFINED) && !ref.test(USED) && !ref.test(BUILT)) {
				ferror_message +=
					"Warning[01-2] in line " + ref.line + ": unused variable '"
					+ S1->name +
					"'!\n";
				//неиспользованная переменная 'a'!
				//unused variable 'a'!
			}
		}
		else if (ref.test(PROC)) {
			if (!ref.test(DEFINED) && ref.test(USED)) {
				ferror_message +=
					"Error[01-3] in line " + ref.line + ": there was no declaration of procedure '"
					+ name +
					"'!\n";
				//не было объявления процедуры 'a'!
				//there was no declaration of procedure 'a'!
				error = true;
			}
			if (ref.test(DEFINED) && !ref.test(USED) && !ref.test(BUILT)) {
				ferror_message +=
					"Warning[01-4] in line " + ref.line + ": unused procedure '"
					+ name +
					"'!\n";
				//неиспользованная процедура 'a'!
				//unused procedure 'a'!
			}
		}
	}
	if (error) return 1;
	return 0;}
int tSM::p02(){ //    PROG -> CALCS
	return 0;}
int tSM::p03(){ //    PROG -> DEFS
	return 0;}
int tSM::p04(){ //    PROG -> DEFS CALCS
	return 0;}
int tSM::p05(){ //       E -> $id
	string name = S1->name;
	if (scope && locals.count(name)) {
		return 0;
	}
	if (scope == 0 && globals.count(name) == 0) {
		ferror_message +=
			"Error[05-1] in line " + S1->line + ": there was no declaration of the variable '"
			+ name +
			"'!\n";
		//не было объявления переменной 'a'!
		//there was no declaration of the variable 'a'!
		return 1;
	}
	tgName& ref = globals[name];
	if (ref.empty()) {
		ref = tgName(VAR | USED, S1->line);
		return 0;
	}
	if (ref.test(VAR)) {
		ref.set(USED);
		return 0;
	}
	if (ref.test(PROC)) {
		if (ref.test(BUILT)) {
			ferror_message +=
				"Error[05-2] in line " + S1->line + ": the built-in procedure '"
				+ name +
				"' сannot be used as a variable!\n";
			//встроенная процедура 'abs' не может быть использованна в качестве переменной!
			//the built-in procedure 'abs' cannot be used as a variable!
			return 1;
		}
		if (scope && locals.count(name) == 0) {
			ferror_message +=
				"Error[05-3] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a reference to a variable;\n" +
				"\tit earlier in line " + ref.line + " it was declared as a procedure!\n";
			//имя 'a' не может быть использовано в качестве ссылки на переменную;
			//ранее в строке 2 оно было объявлено как процедура!
			//the name 'a' cannot be used as a reference to a variable;
			//earlier in line 2 it was declared as a procedure!
			return 1;
		}
		if (scope == 0) {
			ferror_message +=
				"Error[05-4] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a reference to a global variable;\n" +
				"\tearlier in line " + ref.line + " it was declared as a procedure!\n";
			//имя 'a' не может быть использовано в качестве ссылки на глобальную переменную;
			//ранее в строке 2 оно было объявлено как процедура!
			//the name 'a' cannot be used as a reference to a global variable;
			//earlier in line 2 it was declared as a procedure!
			return 1;
		}
	}
	return 0;}
int tSM::p06(){ //       E -> $int
	return 0;}
int tSM::p07(){ //       E -> $dec
	return 0;}
int tSM::p08(){ //       E -> AREX
	return 0;}
int tSM::p09(){ //       E -> COND
	return 0;}
int tSM::p10(){ //       E -> EASYLET
	return 0;}
int tSM::p11(){ //       E -> CPROC
	string name = S1->name;
	tgName& ref = globals[name];
	if (ref.empty()) {
		ref = tgName(PROC | USED);
		ref.line = S1->line;
		ref.arity = S1->count;
		ref.types = S1->types;
	}
	else {
		if (ref.test(VAR)) {
			ferror_message +=
				"Error[11-1] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a reference to the procedure;\n" +
				"\tearlier in line " + ref.line + " it was declared as a variable!\n";
			//имя 'a' не может быть использовано в качестве ссылки на процедуру;
			//ранее в строке 2 оно было объявлено как переменная!
			//the name 'a' cannot be used as a reference to the procedure;
			//earlier in line 2 it was declared as a variable!
			return 1;
		}
		if (scope && locals.count(name) && ref.test(BUILT)) {
			ferror_message +=
				"Error[11-2] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a built-in procedure;\n" +
				"\tpreviously, it was declared as a local variable (or parameter) in the procedure!\n";
			//имя 'abc' не может быть использовано в качестве встроенной процедуры;
			//ранее оно было объявлено как локальная переменная (или параметр) в процедуре!
			//the name 'abc' cannot be used as a built-in procedure;
			//previously, it was declared as a local variable (or parameter) in the procedure!
			return 1;
		}
		if (scope && locals.count(name)) {
			ferror_message +=
				"Error[11-3] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a procedure;\n" +
				"\tpreviously, it was declared as a local variable (or parameter) in the procedure!\n";
			//имя 'abc' не может быть использовано в качестве процедуры;
			//ранее оно было объявлено как локальная переменная (или параметр) в процедуре!
			//the name 'abc' cannot be used as a procedure;
			//previously, it was declared as a local variable (or parameter) in the procedure!
			return 1;
		}
		if (S1->count != ref.arity && !ref.test(BUILT)) {
			ferror_message +=
				"Error[11-4] in line " + S1->line + ": procedure '"
				+ S1->name +
				"' was declared earlier on line " +
				ref.line + " with a different number of arguments!\n";
			//процедура 'a' объявлена ранее на строке 2 с другим количеством аргументов!
			//procedure 'a' was declared earlier on line 2 with a different number of arguments!
			return 1;
		}
		if (S1->count != ref.arity && ref.test(BUILT)) {
			ferror_message +=
				"Error[11-5] in line " + S1->line + ": built-in procedure '"
				+ S1->name +
				"'  was declared earlier with a different number of arguments!\n";
			//встроенная процедура 'abc' объявлена ранее с другим количеством аргументов!
			//built-in procedure 'abc' was declared earlier with a different number of arguments!
			return 1;
		}
		ref.set(USED);
	}
	return 0;}
int tSM::p12(){ // EASYLET -> HEASYL E )
	return 0;}
int tSM::p13(){ //  HEASYL -> ( let ( )
	return 0;}
int tSM::p14(){ //  HEASYL -> HEASYL INTER
	return 0;}
int tSM::p15(){ //    AREX -> HAREX E )
	return 0;}
int tSM::p16(){ //   HAREX -> ( AROP
	return 0;}
int tSM::p17(){ //   HAREX -> HAREX E
	return 0;}
int tSM::p18(){ //    AROP -> +
	return 0;}
int tSM::p19(){ //    AROP -> -
	return 0;}
int tSM::p20(){ //    AROP -> *
	return 0;}
int tSM::p21(){ //    AROP -> /
	return 0;}
int tSM::p22(){ //   CPROC -> HCPROC )
	return 0;}
int tSM::p23(){ //  HCPROC -> ( $id
	S1->name = S2->name;
	return 0;}
int tSM::p24(){ //  HCPROC -> HCPROC E
	S1->count++;
	return 0;}
int tSM::p25(){ //    COND -> ( cond BRANCHES )
	return 0;}
int tSM::p26(){ //BRANCHES -> ELSE
	return 0;}
int tSM::p27(){ //BRANCHES -> CLAUS BRANCHES
	return 0;}
int tSM::p28(){ //   CLAUS -> ( BOOL E )
	return 0;}
int tSM::p29(){ //    ELSE -> ( else ELSEB )
	return 0;}
int tSM::p30(){ //   ELSEB -> E
	return 0;}
int tSM::p31(){ //   ELSEB -> INTER ELSEB
	return 0;}
int tSM::p32(){ //     STR -> $str
	return 0;}
int tSM::p33(){ //     STR -> SIF
	return 0;}
int tSM::p34(){ //     SIF -> ( if BOOL STR STR )
	return 0;}
int tSM::p35(){ //    BOOL -> $bool
	return 0;}
int tSM::p36(){ //    BOOL -> $idq
	string name = S1->name;
    if (scope && locals.count(name)) {
        return 0;
    }
    ferror_message+=
		"Error[36-1] in line "+ S1->line +": boolean variable '"
		+name+
		"' can't exist"+"\n";
		//логическая переменная 'a?' не может существовать!
		//boolean variable 'a?' can't exist!
    return 1;}
int tSM::p37(){ //    BOOL -> REL
	return 0;}
int tSM::p38(){ //    BOOL -> ( not BOOL )
	return 0;}
int tSM::p39(){ //    BOOL -> OR
	return 0;}
int tSM::p40(){ //    BOOL -> CPRED
	string name = S1->name;
    int count = S1->count;
    int types = S1->types;
    if (scope) {
        if (locals.count(name)) {
            ferror_message+=
				"Error[40-1] in line "+ S1->line +": the name '"
				+name+
				"' is already used in this procedure;\n" + 
				"\tit cannot be used as a procedure call!\n";
				//имя 'a?' уже используется в данной процедуре; 
				//это не может быть исользовано в качестве вызова процедуры!
				//name 'a?' is already used in this procedure; 
				//it cannot be used as a procedure call!
            return 1;
        }
    }
    do {
        tgName &ref = globals[name];
        if (ref.empty()) {
            ref = tgName(PROC | USED, S1->line, count, types);
            break;
        }
        if (ref.arity != count) {
            ferror_message+=
				"Error[40-2] in line "+ S1->line +": procedure '"
				+name+
				"'  was declared earlier on line "+ ref.line +"with a different number of arguments!\n";
			//процедура 'a' объявлена ранее на строке 2 с другим количеством аргументов!
			//procedure 'a' was declared earlier on line 2 with a different number of arguments!
            return 1;
        }

        if (ref.types != types) {
            ferror_message+=
				"Error[40-3] in line "+ S1->line +": procedure '"
				+name+
				"' was declared earlier on line"+ ref.line +"with arguments of other types!\n";
			//процедура 'a' объявлена ранее на строке 2 с аргументами других типов!
			//procedure 'a' was declared earlier on line 2 with arguments of other types!
            return 1;
        }
        if (!ref.test(USED))
            ref.set(USED);
    } while (false);
	return 0;}
int tSM::p41(){ //      OR -> ( or ORARGS )
	return 0;}
int tSM::p42(){ //  ORARGS -> BOOL ORARGS
	return 0;}
int tSM::p43(){ //  ORARGS -> BOOL
	return 0;}
int tSM::p44(){ //   CPRED -> ( $idq )
	S1->name = S2->name;
	S1->line = S2->line;
    S1->count = 0;
    S1->types = 0;
	return 0;}
int tSM::p45(){ //   CPRED -> ( $idq PDARGS )
	S1->name = S2->name;
	S1->line = S2->line;
    S1->count = S3->count;
    S1->types = S3->types;
	return 0;}
int tSM::p46(){ //  PDARGS -> ARG
	S1->count = 1;
	return 0;}
int tSM::p47(){ //  PDARGS -> ARG PDARGS
	S1->types = ((S2->types) << 1) + (S1->types);
	S1->count= S2->count+1;
	return 0;}
int tSM::p48(){ //     ARG -> E
	S1->types = 0;
	return 0;}
int tSM::p49(){ //     ARG -> BOOL
	S1->types = 1;
	return 0;}
int tSM::p50(){ //     REL -> ( = E E )
	return 0;}
int tSM::p51(){ //     REL -> ( >= E E )
	return 0;}
int tSM::p52(){ // DISPSET -> ( display E )
	return 0;}
int tSM::p53(){ // DISPSET -> ( display BOOL )
	return 0;}
int tSM::p54(){ // DISPSET -> ( display STR )
	return 0;}
int tSM::p55(){ // DISPSET -> ( newline )
	return 0;}
int tSM::p56(){ // DISPSET -> SET
	return 0;}
int tSM::p57(){ //   INTER -> DISPSET
	return 0;}
int tSM::p58(){ //   INTER -> E
	return 0;}
int tSM::p59(){ //   CALCS -> CALC
	return 0;}
int tSM::p60(){ //   CALCS -> CALCS CALC
	return 0;}
int tSM::p61(){ //    CALC -> E
	return 0;}
int tSM::p62(){ //    CALC -> BOOL
	return 0;}
int tSM::p63(){ //    CALC -> STR
	return 0;}
int tSM::p64(){ //    CALC -> DISPSET
	return 0;}
int tSM::p65(){ //    DEFS -> DEF
	return 0;}
int tSM::p66(){ //    DEFS -> DEFS DEF
	return 0;}
int tSM::p67(){ //     DEF -> PRED
	return 0;}
int tSM::p68(){ //     DEF -> VAR
	string name = S1->name;
	tgName& ref = globals[name];
	if (ref.empty()) {
		ref = tgName(VAR | DEFINED);
		ref.line = S1->line;
		ref.arity = S1->count;
		return 0;
	}
	if (ref.test(PROC)) {
		if (ref.test(BUILT)) {
			ferror_message +=
				"Error[68-1] in line " + S1->line + ": the name '"
				+ name +
				"' cannot be used as a reference to a variable;\n" +
				"\tearlier it was declared as a built-in procedure!\n";
			//имя 'abs' не может быть использовано в качестве ссылки на переменную;
			//ранее оно было объявлено как встроенная процедура!
			//the name 'abs' cannot be used as a reference to a variable;
			//earlier it was declared as a built-in procedure!
			return 1;
		}
		ferror_message +=
			"Error[68-2] in line " + S1->line + ": the name '"
			+ name +
			"' cannot be used as a reference to a variable;\n" +
			"\tearlier in line " + ref.line + " it was declared as a  procedure!\n";
			//имя 'a' не может быть использовано в качестве ссылки на переменную;
			//ранее в строке 2 оно было объявлено как процедура!
			//the name 'a' cannot be used as a reference to a variable;
			//earlier in line 2 it was declared as a  procedure!
		return 1;
	}
	if (ref.test(BUILT)) {
		ferror_message +=
			"Error[68-3] in line " + S1->line + ": the variable '"
			+ S1->name +
			"' is a constant!\n";
		//переменная 'e' является константой!
		//the variable 'e' is a constant!
		return 1;
	}
	if (ref.test(DEFINED)) {
		ferror_message +=
			"Error[68-4] in line " + S1->line + ": the declaration of the variable '"
			+ S1->name +
			"' is already on line "
			+ ref.line + "!\n";
		//объявление переменной 'a' уже есть на строке 2!
		//the declaration of the variable 'a' is already on line 2!
		return 1;
	}
	if (ref.test(USED)) {
		ref.set(DEFINED);
		ref.line = S1->line;
	}
	return 0;}
int tSM::p69(){ //     DEF -> PROC
	return 0;}
int tSM::p70(){ //    PRED -> HPRED BOOL )
	string name = S1->name;
    int count = S1->count;
    int types = S1->types;
    tgName &ref = globals[name];
    if (ref.empty()) {
        ref = tgName(PROC | DEFINED, S1->line, count, types);
    } else if (ref.test(DEFINED)) {
    	ferror_message+=
             "Error[70-1] in line "+ S1->line +": the initialization of procedure '"
              +name+
             "' is already on line " + ref.line +"\n";
			//инициализация процедуры 'a' уже есть на строке 2!
			//the initialization of procedure 'a' is already on line 2!
        return 1;
    } else {
        if (ref.arity != count) {
            ferror_message+=
				"Error[70-2] in line "+ S1->line +": procedure '"
				+name+
				"' was declared earlier on line " + ref.line +"with a different number of arguments!\n";
			//процедура 'a?' объявлена ранее на строке 2 с другим количеством аргументов!
			//procedure 'a?' was declared earlier on line 2 with a different number of arguments!
            return 1;
        } else if (ref.types != types) {
cout<<ref.types <<" "<< types<<'\n';
			ferror_message+=
             "Error[70-3] in line "+ S1->line +": procedure '"
              +name+
             "' was declared earlier on line " + ref.line +"with arguments of other types\n";
			//процедура 'a?' объявлена ранее на строке 2 с аргументами других типов!
			//procedure 'a?' was declared earlier on line 2 with arguments of other types!
            return 1;
        } else {
            ref.set(DEFINED);
        }
    }
    locals.clear();
    scope = 0;
	return 0;}
int tSM::p71(){ //   HPRED -> PDPAR )
	scope = 1;
	return 0;}
int tSM::p72(){ //   PDPAR -> ( define ( $idq
	S1->line = S4->line;
	S1->name = S4->name;
    S1->count = 0;
	return 0;}
int tSM::p73(){ //   PDPAR -> PDPAR $idq
	if (locals.count(S2->name)) {
		ferror_message+=
             "Error[73-1] in line "+ S2->line +": the declaration of the parameter '"
              +S2->name+
             "' is already\n";
		//объявление параметра 'a' уже есть!
		//the declaration of the parameter 'a' is already there!
        return 1;
    }
    locals.insert(S2->name);
    S1->types = S1->types | 1 << (S1->count);
    ++S1->count;
	return 0;}
int tSM::p74(){ //   PDPAR -> PDPAR $id
	if (locals.count(S2->name)) {
		ferror_message+=
             "Error[74-1] in line "+ S2->line +": the declaration of the parameter '"
              +S2->name+
             "' is already there\n";
		//объявление параметра 'a' уже есть!
		//the declaration of the parameter 'a' is already there!
        return 1;
    }
    locals.insert(S2->name);
    ++S1->count;
    S1->types = S1->types | 0 << (S1->count);
	return 0;}
int tSM::p75(){ //     SET -> ( set! $id E )
	S1->name = S3->name; 
	string name = S1->name;
	if (scope && locals.count(name)) {
		return 0;
	}
	if (scope == 0 && globals.count(name) == 0) {
		ferror_message +=
			"Error[75-1] in line " + S1->line + ": there was no declaration of the variable '"
			+ name +
			"'!\n";
		//не было объявления переменной 'a'!
		//there was no declaration of the variable 'a'!
		return 1;
	}
	tgName& ref = globals[name];
	if (ref.test(PROC)) {
		if (ref.test(BUILT)) {
			ferror_message +=
				"Error[75-2] in line " + S1->line + ": the object '"
				+ S1->name +
				"' is a built-in procedure\n\t"
				+ "and cannot have a variable value!\n";
			//объект 'abs' является встроенной процедурой и не может иметь значение переменной!
			//object 'abs' is a built-in procedure and cannot have a variable value!
			return 1;
		}
		ferror_message +=
			"Error[75-3] in line " + S1->line + ": the '"
			+ S1->name +
			"' object is declared as a procedure on line " + ref.line + 
			"\n\tand cannot have a variable value!\n";
		//объект 'abs' объявлена как процедура на строке 2 и не может иметь значение переменной!
		//the 'abs' object is declared as a procedure on line 2 and cannot have a variable value!
		return 1;
	}
	if (ref.test(BUILT)) {
		ferror_message +=
			"Error[75-4] in line " + S1->line + ": the variable '"
			+ S1->name +
			"' is  a constant!\n";
		//переменная 'e' является константой!
		//the variable 'e' is a constant!
		return 1;
	}
	return 0;}
int tSM::p76(){ //     VAR -> VARDCL VARINI )
	if (scope && locals.count(S1->name) == 0 && globals.count(S1->name) == 0) {
		locals.insert(S1->name);
		return 0;
	}
	if (scope && locals.count(S1->name)) {
		ferror_message +=
			"Error[76-1] in line " + S1->line + ": the variable '"
			+ S1->name +
			"' is already defined here!\n";
		
		//переменная 'a' здесь уже определена!
		//the variable 'a' is already defined here!
		return 1;
	}
	if (scope && globals.count(S1->name)) {
		tgName& ref = globals[S1->name];
		if (ref.test(VAR)) {
			if (ref.test(BUILT)) {
				ferror_message +=
					"Warning[76-2] in line " + S1->line + ": the variable '"
					+ S1->name +
					"' has the same name as the built-in variable!\n";
				//переменная 'e' имеет такое же имя, как и встроенная переменная!
				//the variable 'e' has the same name as the built-in variable!
			}
			else {
				ferror_message +=
					"Warning[76-3] in line " + S1->line + ": the variable '"
					+ S1->name +
					"' has the same name \n\t"
					"as the global variable, defined on line " + ref.line + "!\n";
				//у переменной 'a' такое же имя, как у глобальной переменной, определённой на строке
				//the variable 'a' has the same name as the global variable, defined on line
			}
		}
		if (ref.test(PROC)) {
			if (ref.test(BUILT)) {
				ferror_message +=
					"Warning[76-4] in line " + S1->line + ": the variable '"
					+ S1->name +
					"' has the same name as the built-in procedure!\n";
				//переменная 'abs' имеет такое же имя, как и встроенная процедура!
				//the variable 'abs' has the same name as the built-in procedure!
			}
			else {
				ferror_message +=
					"Warning[76-5] in line " + S1->line + ": the procedure '"
					+ S1->name +
					"' has the same name \n\t"
					"as the procedure, defined on line " + ref.line + "!\n";
				//у переменной 'a' такое же имя, как у процедуры, определённой на строке
				//the variable 'a' has the same name as the procedure, defined on line
			}
		}
		locals.insert(S1->name);
	}
	return 0;}
int tSM::p77(){ //  VARDCL -> ( define $id
	S1->name = S3->name;
	return 0;}
int tSM::p78(){ //  VARINI -> $int
	return 0;}
int tSM::p79(){ //  VARINI -> $dec
	return 0;}
int tSM::p80(){ //    PROC -> HPROC PCBODY )
	locals.clear();
	scope = 0;
	return 0;}
int tSM::p81(){ //   HPROC -> PCPAR )
	scope = 1;
	string name = S1->name;
	tgName& ref = globals[name];
	if (ref.empty()) {
		ref = tgName(PROC | DEFINED);
		ref.line = S1->line;
		ref.arity = S1->count;
		ref.types = S1->types;
		return 0;
	}
	if (ref.test(VAR)) {
		if (ref.test(BUILT)) {
			ferror_message +=
				"Error[81-1] in line " + S1->line + ": the built-in constant '"
				+ name +
				"' \n\t cannot be used as a procedure name!\n";
			//встроенную константу 'e' нельзя использовать в качестве имени процедуры!
			//the built-in constant 'e' cannot be used as a procedure name!
			return 1;
		}
		ferror_message +=
			"Error[81-2] in line " + S1->line + ": the object '"
			+ S1->name +
			"' is not a procedure,\n\t " + "variable '" +
			S1->name + "' was defined on the line " + ref.line + "!\n";
		//объект 'a' не процедура, переменная 'a' была определена на строке!
		//object 'a' is not a procedure, variable 'a' was defined on the line!
		return 1;
	}
	if (ref.test(BUILT)) {
		ferror_message +=
			"Error[81-3] in line " + S1->line + ": the built-in procedure '"
			+ name +
			"' \n\t cannot be used as a procedure name!\n";
		//встроенную процедуру 'abs' нельзя использовать в качестве имени процедуры!
		//the built-in procedure 'abs' cannot be used as a procedure name!
		return 1;
	}
	if (ref.test(DEFINED)) {
		ferror_message +=
			"Error[81-4] in line " + S1->line + ": the procedure '"
			+ S1->name +
			"' is already defined on line " + ref.line + "!\n";
		//процедура 'f' уже определена на строке!
		//the procedure 'f' is already defined on line!
		return 1;
	}
	if (ref.test(USED)) {
		if (S1->count != ref.arity) {
			ferror_message +=
				"Error[81-5] in line " + S1->line + ": procedure '"
				+ S1->name +
				"' was used\n\t" +
				"earlier on line " + ref.line + " with arity " + Uint_to_str(ref.arity)
				+ ",\n\t given " + Uint_to_str(S1->count) + "!\n";
			// процедура 'f' была использована раньше на строке k с арностью n, дана m!
			// procedure 'f' was used earlier on line k with arity n, given m!
			return 1;
		}
		ref.set(DEFINED);
	}
	return 0;}
int tSM::p82(){ //  PCBODY -> E
	S1->types = 1;
	return 0;}
int tSM::p83(){ //  PCBODY -> INTER PCBODY
	if (S2->types == 0) {
		ferror_message +=
			"Error[83-1] in line " + S2->line + ": the definition of the variable '"
			+ S2->name +
			"'\n\t is not at the beginning of the procedure body!\n";
		//определение переменной 'a' не в начале тела процедуры
		//the definition of the variable 'a' is not at the beginning of the procedure body
		return 1;
	}
	S1->types = 1;
	return 0;}
int tSM::p84(){ //  PCBODY -> VAR PCBODY
	S1->types = 0;
	return 0;}
int tSM::p85(){ //   PCPAR -> ( define ( $id
	S1->name = S4->name;
	return 0;}
int tSM::p86(){ //   PCPAR -> PCPAR $id
	if (locals.count(S2->name)) {
		ferror_message +=
			"Error[86-1] in line " + S2->line + ": the procedure '"
			+ S1->name +
			"' duplicates \n\tthe '"
			+ S2->name + "' parameter!\n";
		//в процедуре 'f' дублируется параметр 'x'
		//the 'f' procedure duplicates the 'x' parameter
		return 1;
	}

	if (S2->name == S1->name) {
		ferror_message +=
			"Warning[86-2] in line " + S2->line + ": the procedure '"
			+ S1->name +
			"' has the same name \n"
			"\tas its parameter!\n";
		//у процедуры 'f' такое же имя, как у ее параметра
		//the procedure 'f' has the same name as its parameter
	}
	if (globals.count(S2->name)) {
		tgName& ref = globals[S2->name];
		if (ref.test(BUILT)) {
			if (ref.test(VAR)) {
				ferror_message +=
					"Warning[86-3] in line " + S2->line + ": the parameter '"
					+ S2->name +
					"' has the same name \n\t"
					"as the built-in variable!\n";
				//у параметра 'e' такое же имя, как у встроенной переменной!
				//the parameter 'e' has the same name as the built-in variable!
			}
			if (ref.test(PROC)) {
				ferror_message +=
					"Warning[86-4] in line " + S2->line + ": the parameter '"
					+ S2->name +
					"' has the same name \n\t"
					"as the built-in procedure!\n";
				//у параметра 'abs' такое же имя, как у встроенной процедуры!
				//the parameter 'abs' has the same name as the built-in procedure!
			}
		}
	}
	locals.insert(S2->name);
	++S1->count;
	return 0;}
//_____________________
int tSM::p87(){return 0;} int tSM::p88(){return 0;} 
int tSM::p89(){return 0;} int tSM::p90(){return 0;} 
int tSM::p91(){return 0;} int tSM::p92(){return 0;} 
int tSM::p93(){return 0;} int tSM::p94(){return 0;} 
int tSM::p95(){return 0;} int tSM::p96(){return 0;} 
int tSM::p97(){return 0;} int tSM::p98(){return 0;} 
int tSM::p99(){return 0;} int tSM::p100(){return 0;} 
int tSM::p101(){return 0;} int tSM::p102(){return 0;} 
int tSM::p103(){return 0;} int tSM::p104(){return 0;} 
int tSM::p105(){return 0;} int tSM::p106(){return 0;} 
int tSM::p107(){return 0;} int tSM::p108(){return 0;} 
int tSM::p109(){return 0;} int tSM::p110(){return 0;} 


