/*  AAP   */
#include "mlisp.h"
double root/*2*/ (double a, double b);
double half__interval/*14*/ (double a, double b
         , double fa, double fb);
double __AAP__try/*26*/ (double neg__point, double pos__point);
bool close__enough_Q/*41*/ (double x, double y);
double average/*43*/ (double x, double y);
extern double tolerance/*45*/;
extern double total__iterations/*46*/;
double f/*47*/ (double z);
bool f_Q/*53*/ ();
bool t_Q/*54*/ ();
//________________
double root/*2*/ (double a, double b){
 double temp/*3*/ ( 0. );
         temp = half__interval(a, b, f(a), f(b));
         display("Total number of iteranions=");
         display(total__iterations);
         newline();
         display("[");
         display(a);
         display(" , ");
         display(b);
         display("]");
         return
 temp;
         }
double half__interval/*14*/ (double a, double b
         , double fa, double fb){
 double root/*15*/ ( 0. );
         total__iterations = 0.;
         root = (!((!(!((fa>=0.))) || !(!((0.>=fb)))))
        ? __AAP__try(a, b)
        : !((!(!((0.>=fa))) || !(!((fb>=0.)))))
        ? __AAP__try(b, a)
        : ((b + 1.)));
         newline();
         return
 root;
         }
double __AAP__try/*26*/ (double neg__point, double pos__point){
 double midpoint/*27*/ ( 0. );
         double test__value/*28*/ ( 0. );
         midpoint = average(neg__point, pos__point);
         display("+");
         total__iterations = (total__iterations + 1.);
         return
 (close__enough_Q(neg__point, pos__point)
        ? midpoint
        : (test__value = f(midpoint),
         (!((0.>=test__value))
        ? __AAP__try(neg__point, midpoint)
        : !((test__value>=0.))
        ? __AAP__try(midpoint, pos__point)
        : (midpoint))));
         }
bool close__enough_Q/*41*/ (double x, double y){
 return
 !((abs((x - y))>=tolerance));
         }
double average/*43*/ (double x, double y){
 return
 ((x + y) * (1. / 2.0e+0));
         }
double tolerance/*45*/ = .01e-1;
         double total__iterations/*46*/ = 0.;
         double f/*47*/ (double z){
 return
 (atan(z) + (- log((z + 6.))) + 2.4e+0);
         }
bool f_Q/*53*/ (){
 return
 false;
         }
bool t_Q/*54*/ (){
 return
 !(f_Q());
         }
int main(){
 display(t_Q());
         newline();
         display("Variant 206-18\n");
        display(root(-3., -1.79e+0));
         newline();
         display("(c) Artemiy Pochechura 2022\n");
        std::cin.get();
         return
 0;
         }